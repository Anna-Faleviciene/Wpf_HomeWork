﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp19_1.Models
{
    class Ariph
    {
       public static double Add(double a) => (2*Math.PI)*a;
    }
}
